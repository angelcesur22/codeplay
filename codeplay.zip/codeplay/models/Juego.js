const mongoose = require('mongoose');

const juegoSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  descripcion: { type: String, required: true },
  html: { type: String, required: true },
  css: { type: String, required: true },
  javascript: { type: String, required: true },
});

module.exports = mongoose.model('Juego', juegoSchema);
