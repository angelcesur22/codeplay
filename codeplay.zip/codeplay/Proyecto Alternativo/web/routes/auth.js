const express = require('express');
const bcrypt = require('bcrypt');
const User = require('web/models/User.js');
const router = express.Router();

// Ruta para el registro
router.post('/register', async (req, res) => {
    try {
        const { usuario, correo, contraseña } = req.body;

        // Validar campos requeridos
        if (!usuario || !correo || !contraseña) {
            return res.status(400).send({ message: 'Todos los campos son obligatorios.' });
        }

        // Hash de la contraseña
        const hashedPassword = await bcrypt.hash(contraseña, 10);

        // Crear un nuevo usuario
        const newUser = new User({
            usuario,
            correo,
            contraseña: hashedPassword
        });

        // Guardar en la base de datos
        const savedUser = await newUser.save();
        res.status(201).send({ message: 'Usuario registrado exitosamente', user: savedUser });
    } catch (error) {
        if (error.code === 11000) {
            res.status(400).send({ message: 'El usuario o correo ya está registrado.' });
        } else {
            res.status(500).send({ message: 'Error interno del servidor.', error });
        }
    }
});

