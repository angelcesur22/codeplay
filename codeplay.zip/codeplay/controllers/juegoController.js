// controllers/juegoController.js
const Juego = require('../models/Juego,js');

// Obtener todos los juegos
exports.obtenerJuegos = async (req, res) => {
  try {
    const juegos = await Juego.find();
    res.json(juegos);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener los juegos' });
  }
};
