const userServices = require('../services/userService');
const User = require('../models/User'); // Importar el modelo User
const getUsers = async (req, res) => {
  const users = await userServices.getUsers();
  console.log(users);
  res.status(200).send(users);
};

const registerUser = async (req, res) => {
    try {
        const { username, password } = req.body;
        console.log(req.body);
        console.log(req.body.password);
        console.log(username, password);

        // Intenta registrar el usuario llamando a los servicios
        const user = await userServices.registerUser(username, password);

        if (user) {
            // Guardar el nuevo usuario en la base de datos
            await user.save();
            console.log('Usuario registrado con éxito:', username);

            // Respuesta con redirección a login.html
            res.status(200).json({ redirect: 'login.html' });
        } else {
            console.error('Error al registrar el usuario.');
            res.status(500).send('Error registering new user, please try again.');
        }
    } catch (err) {
        console.error('Error interno al registrar el usuario:', err);
        res.status(500).send('Error interno al registrar el usuario.');
    }
};


const loginUser = async (req, res) => {
    const { usuario, contraseña } = req.body;

    console.log('Datos recibidos del cliente:', { usuario, contraseña });

    if (!usuario || !contraseña) {
        console.log('Faltan datos en la solicitud');
        return res.status(400).send('El nombre de usuario y la contraseña son obligatorios.');
    }

    try {
        const user = await User.findOne({ usuario }); // Busca en la base de datos
        console.log('Usuario encontrado en la base de datos:', user);

        if (!user) {
            console.log('Usuario no encontrado.');
            return res.status(401).send('Usuario no encontrado.');
        }

        if (user.contraseña !== contraseña) {
            console.log('Contraseña incorrecta.');
            console.log('Contraseña ingresada:', contraseña);
            console.log('Contraseña almacenada:', user.contraseña);
            return res.status(401).send('Contraseña incorrecta.');
        }

        console.log('Inicio de sesión exitoso para el usuario:', usuario);
        // Enviar respuesta con redirección
        res.status(200).json({ redirect: 'index.html' });
    } catch (err) {
        console.error('Error al iniciar sesión:', err);
        res.status(500).send('Error interno del servidor.');
    }
};

module.exports = {
    getUsers,
    registerUser,
    loginUser
};